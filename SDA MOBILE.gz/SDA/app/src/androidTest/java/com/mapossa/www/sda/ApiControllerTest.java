package com.mapossa.www.sda;


import android.support.test.runner.AndroidJUnit4;

import com.mapossa.www.sda.ThinkSpeack.controller.ApiController;
import com.mapossa.www.sda.ThinkSpeack.model.Field;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ApiControllerTest {

    ApiController ctrlField = new ApiController();
    @Test
    public void useFindById_isCorrect() {
        String response = "{\\\"channel\\\":{\\\"id\\\":514579,\\\"name\\\":\\\"sda\\\",\\\"description\\\":\\\"Sensor data analytic\\\",\\\"latitude\\\":\\\"0.0\\\",\\\"longitude\\\":\\\"0.0\\\",\\\"field1\\\":\\\"temperateur\\\",\\\"field2\\\":\\\"humidite\\\",\\\"field3\\\":\\\"lumiere\\\",\\\"created_at\\\":\\\"2018-06-08T08:15:52Z\\\",\\\"updated_at\\\":\\\"2018-07-14T10:01:14Z\\\",\\\"last_entry_id\\\":16},\\\"feeds\\\":[]}\n";
        ArrayList<Field> result = null;
        try {
//            System.out.println((new JSONObject(response)).toString());
            result = ctrlField.jsonHowManyFields(new JSONObject(response));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        assertEquals(3, result.size());
        assertEquals(1, result.get(0).getId());
        assertEquals(2, result.get(1).getId());
        assertEquals(3, result.get(3).getId());
    }
}
