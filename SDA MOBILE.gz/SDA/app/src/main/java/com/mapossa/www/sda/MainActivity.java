package com.mapossa.www.sda;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.mapossa.www.sda.Activity.ConfigActivity;
import com.mapossa.www.sda.Activity.InitAppActivity;
import com.mapossa.www.sda.Network.HttpRequest;
import com.mapossa.www.sda.ThinkSpeack.controller.ApiController;
import com.mapossa.www.sda.ThinkSpeack.controller.DataController;
import com.mapossa.www.sda.ThinkSpeack.controller.FieldController;
import com.mapossa.www.sda.ThinkSpeack.controller.LineChartController;
import com.mapossa.www.sda.ThinkSpeack.model.Data;
import com.mapossa.www.sda.ThinkSpeack.model.Field;
import com.mapossa.www.sda.ThinkSpeack.view.ViewAlerteAdapter;
import com.mapossa.www.sda.ThinkSpeack.view.ViewApiAdapter;
import com.mapossa.www.sda.ThinkSpeack.view.ViewSourceAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;
    private static TabLayout tabs;
    public static boolean tabMakeChange = false;
    public static boolean ATTENTE_ACTIVE = false;
    private  static int positionPager = 1;
    private String API_KEY = "2oeEEE";
    private MediaPlayer son;
    static ProgressBar progress;

    static String url ="https://thingspeak.com/channels/514579/field/2.json";
    private final int jsoncode = 1;
    private int STAPE = 1;
    private int ID_FIELD = 2;
    private int ID_FEED = 514579;

    static Runnable runnableUpdateData;
    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        tabs = (TabLayout) findViewById(R.id.tabBar);
//        tabs.addTab( tabs.newTab().setText("FEAV"));
        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        tabs.setupWithViewPager(mViewPager,true);
        int id_add_ressource = R.drawable.ic_launcher_foreground;
        tabs.getTabAt(0).setText("ACCEUIL");
        tabs.getTabAt(1).setText("SOURCES");
        tabs.getTabAt(2).setText("ALERTES");
        tabs.getTabAt(3).setText("CONFIG");
        (new FieldController()).setActive((new ApiController()).getActive());
        mViewPager.setCurrentItem(this.positionPager-1);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InitAppActivity.OPEN_APP = true;
                Context context = view.getContext();
                Intent intent = new Intent(context, InitAppActivity.class);
                context.startActivity(intent);
            }
        });
        son =  MediaPlayer.create(this,R.raw.inc);

        if((new ApiController()).getId()>0)
            ID_FEED = (new ApiController()).getId();
        if((new ApiController()).getActive()>0)
            ID_FIELD = (new ApiController()).getActive();
        else
            ID_FIELD =1;
        runnableUpdateData = new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i <= 100; i++) {
                    final int value = i;
                    try {
                        parseJson();
                        try {
                            Thread.sleep(10000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

//            Context context = this.getApplicationContext();
//            Intent intent = new Intent(context, ConfigActivity.class);
//            context.startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        public PlaceholderFragment() {

        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();

            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }
        private int getTabSelectedPosition(int position){
            if(position==1)
                return 0;
            return position-1;
        }
        private int changePage(int position){
            if(position==2)
                return R.layout.source_view;
            if(position==3)
                return R.layout.alertes_view;
            if(position==4)
                return R.layout.api_view;
            return R.layout.home_view;
        }
        void setWaiting(ProgressBar p){
            if(ATTENTE_ACTIVE)
                p.setVisibility(View.VISIBLE);
            else
                p.setVisibility(View.INVISIBLE);

        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            int section_id = getArguments().getInt(ARG_SECTION_NUMBER);
            final View rootView = inflater.inflate(changePage(section_id), container, false);
            TextView textView = (TextView) rootView.findViewById(R.id.section_label);
            int tab_selected = 0;
            if(section_id==1) {
                final DataController datasCtrl = new DataController();
                final ApiController apiCtrl = new ApiController();
                final LineChartController chart = new LineChartController(
                        (LineChart) rootView.findViewById(R.id.chart),datasCtrl.getAll(),"Datas Field 1");
                Field f = (new FieldController()).activeField();
                chart.setMax((int)apiCtrl.getMax());
                chart.setMin((int)apiCtrl.getMin());
                chart.refresh(); // refresh

                progress = (ProgressBar) rootView.findViewById(R.id.progressBar);
                setWaiting(progress);
                Button attente = (Button) rootView.findViewById(R.id.waiting);
                final Runnable runnableUpdateChart = new Runnable() {
                    @Override
                    public void run() {

                        for (int i = 0; i <= 100; i++) {
                            chart.setDatas(datasCtrl.getAll());
                            try {
                                Thread.sleep(5000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                };

                final Thread T1= new Thread(runnableUpdateData);
                final Thread T2 = new Thread(runnableUpdateChart);
                attente.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        MediaPlayer.create(rootView.getContext(),R.raw.inc).start();
                        ATTENTE_ACTIVE = ATTENTE_ACTIVE != true;
                        setWaiting(progress);
                        if(ATTENTE_ACTIVE){
                            T1.start();
                        }
                    }
                });
                positionPager = 1;
            }else if(section_id==2){
                RecyclerView recyclerView = rootView.findViewById(R.id.item_list);
                recyclerView.setAdapter(new ViewSourceAdapter());
                positionPager = 2;
            }else  if(section_id==3){
                RecyclerView recyclerView = rootView.findViewById(R.id.item_list);
                recyclerView.setAdapter(new ViewAlerteAdapter());
                positionPager = 3;
            }else if(section_id==4){
                RecyclerView recyclerView = rootView.findViewById(R.id.item_list);
                recyclerView.setAdapter(new ViewApiAdapter());
                positionPager = 4;

                ImageButton confButton = (ImageButton) rootView.findViewById(R.id.apiButton);
                TextView confText = (TextView) rootView.findViewById(R.id.apiKey);
                if ( (new ApiController()).getKey()!=null)
                    confText.setText( (new ApiController()).getKey());
                confButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Context context = view.getContext();
                        Intent intent = new Intent(context, ConfigActivity.class);
                        context.startActivity(intent);
                    }
                });
            }

            tabMakeChange = false;
            return rootView;
        }
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            return PlaceholderFragment.newInstance(position + 1);
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 4;
        }
    }

    public boolean isNetworkAvialable(){
        ConnectivityManager cM = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo nI = cM.getActiveNetworkInfo();
        if(nI != null && nI.isConnected())
            return true;
        return false;
    }
    private  void parseJson() throws IOException, JSONException {

        if (!isNetworkAvialable()) {
            Toast.makeText(this.getApplicationContext(), "Internet is required!", Toast.LENGTH_SHORT).show();
        }
        new AsyncTask<Void, Void, String>(){
            protected String doInBackground(Void[] params) {
                String response="";
                url = "https://thingspeak.com/channels/"+ID_FEED+"/field/"+ID_FIELD+".json";
                HashMap<String, String> map=new HashMap<>();
                try {
                    HttpRequest req = new HttpRequest(MainActivity.url);
                    response = req.prepare(HttpRequest.Method.GET).sendAndReadString();
                } catch (Exception e) {
                    response=e.getMessage();
                }
                return response;
            }
            protected void onPostExecute(String result) {
                onTaskCompleted(result,jsoncode);
            }
        }.execute();
    }
    public void onTaskCompleted(String response, int serviceCode) {
        CharSequence text = response.toString();
        progress.setVisibility(View.INVISIBLE);
        ArrayList<Data> listData = new ArrayList<Data>();

        if (serviceCode == jsoncode) {
            JSONArray dataArray = null;
            try {
                JSONObject jsonObject = new JSONObject(response);
                dataArray = jsonObject.getJSONArray("feeds");

            } catch (JSONException e) {
                e.printStackTrace();
                DataController dataCtrl =  new DataController(listData);
            }
            double oldValue = 0;
            String oldString = "";
            if(dataArray!=null) {
                for (int i = 0; i < dataArray.length(); i++) {
                    JSONObject dataobj = null;
                    try {
                        dataobj = dataArray.getJSONObject(i);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Data data = new Data();
                    try {
                        data.setDate(dataobj.getString("created_at"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        double value = dataobj.getDouble("field" + ID_FIELD);
                        data.setData(value);
                        oldValue = value;
                    }catch (JSONException e) {
                        data.setData(oldValue);
                    }finally {
                    }
                    listData.add(data);
                }
            }
        }else{
            Toast.makeText(this.getApplicationContext(), "Check your internet connexion", Toast.LENGTH_LONG).show();
        }
        DataController dataCtrl =  new DataController(listData);
        if(listData.size()>0){
            Data d = listData.get(listData.size()-1);
            ApiController apiCtrl = new ApiController();
            int max = (int)apiCtrl.getMax();
            int min = (int)apiCtrl.getMin();
            if(d.getData()<=min || d.getData()>=max) {
                MediaPlayer.create(this.getBaseContext(), R.raw.inc).start();
                Toast.makeText(this.getApplicationContext(), "Une Donnee anormale a ete signalee", Toast.LENGTH_LONG).show();

            }
        }
    }
}
