package com.mapossa.www.sda.ThinkSpeack.controller;

import android.provider.ContactsContract;

import com.mapossa.www.sda.ThinkSpeack.model.Data;

import java.util.ArrayList;

public class DataController {
    static ArrayList<Data> champs;
    public DataController() {
        if (champs==null || champs.size()==0) {
            champs = new ArrayList<Data>();
            FieldController fd = new FieldController();
//            champs.add(new Data("12-02-2018 07:00", 0.0));
//            champs.add(new Data("12-02-2018 08:00", 14.0));
//            champs.add(new Data("12-02-2018 09:00", 20.0));
//            champs.add(new Data("12-02-2018 10:00", 11.0));
//            champs.add(new Data("12-02-2018 11:00", 17.0));
//            champs.add(new Data("12-02-2018 12:00", 30.0));
//            champs.add(new Data("12-02-2018 13:00", 23.0));
//            champs.add(new Data("12-02-2018 14:00", 14.0));
//            champs.add(new Data("12-02-2018 15:00", 09.0));
//            champs.add(new Data("12-02-2018 16:00", 15.0));
//            champs.add(new Data("12-02-2018 17:00", 10.0));
//            champs.add(new Data("12-02-2018 18:00", 11.0));
//            champs.add(new Data("12-02-2018 19:00", 13.0));
//            champs.add(new Data("12-02-2018 20:00", 11.0));
        }
    }
    public DataController(ArrayList<Data> list) {
        champs = list;
    }
    public int add(Data champ){
        return 1;
    }
    public int delete(Data champ){
        return 1;
    }
    public Data get(int id){
        return null;
    }
    public ArrayList<Data> getAll(){
        return champs;
    }
}
