package com.mapossa.www.sda.ThinkSpeack.controller;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.mapossa.www.sda.Activity.InitAppActivity;
import com.mapossa.www.sda.ThinkSpeack.model.*;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ApiController {
    static  Api api;
    Context context;
    SharedPreferences preferences;
    public ApiController() {
        context = InitAppActivity.context;
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
        api = new Api();
    }
    public ArrayList<Field> jsonHowManyFields(JSONObject jsonObject){
        ArrayList<Field> fieldsList = new ArrayList<Field>();
        try {
            JSONObject dataArray = jsonObject.getJSONObject("channel");
            Log.d("fieldall",dataArray.toString());
            for (int i = 0; i < 100; i++) {
                try {
                    JSONObject dataobj = dataArray;
                    Log.d("field"+i,dataobj.getString("field"+i));
                    Log.d("responsejson+++", dataobj.toString());
                    if(dataobj.getString("field"+i)!= null || dataobj.getString("field"+i).length()>1){
                        fieldsList.add(new Field("Source N°"+i,i,dataobj.getString("field"+i)));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return fieldsList;
    }
    public Api jsonGetApi(JSONObject jsonObject){
        api = new Api();
        try {
            JSONObject dataobj = jsonObject.getJSONObject("channel");
            try {
                api.setKey(dataobj.getString("field"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return api;
    }

    public String getDescription(){
        String key = preferences.getString("descp",null);
        return key;
    }
    public void setDescription(String key){
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("descp",key);
        editor.apply();
    }
    public String getKey(){
        String key = preferences.getString("key",null);
        return key;
    }
    public void setKey(String key){
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("key",key);
        editor.apply();
    }
    public int getId(){
        int key = preferences.getInt("id",0);
        return key;
    }
    public void setId(int key){
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("id",key);
        editor.apply();
    }

    public int getActive(){
        int key = preferences.getInt("active",0);
        return key;
    }
    public void setActive(int key){
        SharedPreferences.Editor editor = preferences.edit();
        FieldController f = new FieldController();
        editor.putInt("active",key);
        editor.apply();
        f.setActive(key);
    }
    public double getMax() {
        double max;
        max = (double) preferences.getFloat("max",100);
        return max;
    }
    public double getMin() {
        double min;
        min = (double) preferences.getFloat("min",10);
        return min;
    }
    public void setMax(double max) {

        SharedPreferences.Editor editor = preferences.edit();
        editor.putFloat("max",(float) max);
        editor.apply();
    }
    public void setMin(double min) {

        SharedPreferences.Editor editor = preferences.edit();
        editor.putFloat("min",(float) min);
        editor.apply();
    }
}
