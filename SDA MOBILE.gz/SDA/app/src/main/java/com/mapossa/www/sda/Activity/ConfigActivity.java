package com.mapossa.www.sda.Activity;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.mapossa.www.sda.R;
import com.mapossa.www.sda.ThinkSpeack.controller.ApiController;

public class ConfigActivity extends AppCompatActivity {
    private Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);
        context = getApplicationContext();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ApiController apiCtrl = new ApiController();
        //KEY
        final EditText api_key = (EditText) findViewById(R.id.api_key);
        api_key.setText(apiCtrl.getKey());
        ImageButton api_key_img = (ImageButton) findViewById(R.id.api_key_button);
        api_key_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s = api_key.getText().toString();
                apiCtrl.setKey(s);
                Toast.makeText(context,"Update of KEY Succed",Toast.LENGTH_SHORT).show();
            }
        });
        //ID
        final EditText api_id = (EditText) findViewById(R.id.api_id);
        api_id.setText(apiCtrl.getId()+"");
        ImageButton api_id_img = (ImageButton) findViewById(R.id.api_id_button);
        api_id_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int s = (int)Float.parseFloat(api_id.getText().toString());
                apiCtrl.setId(s);
                Toast.makeText(context,"Update of ID Succed",Toast.LENGTH_SHORT).show();
            }
        });


        //MIN
        final EditText api_min = (EditText) findViewById(R.id.api_min);
        api_min.setText(apiCtrl.getMin()+"");
        ImageButton api_min_img = (ImageButton) findViewById(R.id.api_min_button);
        api_min_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int s = (int)Float.parseFloat(api_min.getText().toString());
                apiCtrl.setMin(s);
                Toast.makeText(view.getContext(),"Update of MIN VALUE Succed",Toast.LENGTH_SHORT).show();
            }
        });

        //MAX
        final EditText api_max = (EditText) findViewById(R.id.api_max);
        api_max.setText(apiCtrl.getMax()+"");
        ImageButton api_max_img = (ImageButton) findViewById(R.id.api_max_button);
        api_max_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int s = (int)Float.parseFloat(api_max.getText().toString());
                apiCtrl.setMax(s);
                Toast.makeText(view.getContext(),"Update of MAX VALUE Succed",Toast.LENGTH_SHORT).show();
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

}
