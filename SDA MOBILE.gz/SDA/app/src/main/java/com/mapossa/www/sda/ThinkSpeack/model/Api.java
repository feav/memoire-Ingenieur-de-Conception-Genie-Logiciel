package com.mapossa.www.sda.ThinkSpeack.model;

public class Api {
    private String key;
    private int id;
    private String baseUrl;
    private double min=10;
    private double max=20;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }
}
