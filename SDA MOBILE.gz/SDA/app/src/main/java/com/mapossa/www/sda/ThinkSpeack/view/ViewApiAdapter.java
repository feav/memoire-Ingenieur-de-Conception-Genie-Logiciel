package com.mapossa.www.sda.ThinkSpeack.view;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.mapossa.www.sda.MainActivity;
import com.mapossa.www.sda.R;
import com.mapossa.www.sda.ThinkSpeack.controller.ApiController;
import com.mapossa.www.sda.ThinkSpeack.controller.FieldController;
import com.mapossa.www.sda.ThinkSpeack.model.Field;

import java.awt.font.TextAttribute;
import java.util.ArrayList;
import java.util.List;

public class ViewApiAdapter
        extends RecyclerView.Adapter<ViewApiAdapter.ViewApiHolder> {

    private List<Field> mValues = (new FieldController()).getAll();
    /**
     * ELLE RENVOIE LA VUE DEJA FORME ET REMPLACE LE TMP PAR LA VUE QUI DOIT S AFFICHER
     * @param viewGroup
     * @param i
     * @return
     */
    @NonNull
    @Override
    public ViewApiHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View  view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.api_view_item, viewGroup, false);
        return new ViewApiHolder(view);
    }

    /**
     * DANS CONFIGURE L AFFICHAGE
     * @param viewApiHolder LA VUE MERE DE LA VUE SUR LAQUELLE ON TRAVAIL
     * @param i L INDICE DE L ELEMENT A TRAVAILLER
     */
    @Override
    public void onBindViewHolder(@NonNull ViewApiHolder viewApiHolder, int i) {

        viewApiHolder.name.setText(this.mValues.get(i).getName());
        viewApiHolder.type.setText(this.mValues.get(i).getType());
        viewApiHolder.letter.setText("S"+this.mValues.get(i).getId());
        viewApiHolder.activate.setChecked(this.mValues.get(i).isActivate());
        final int id = this.mValues.get(i).getId();
        viewApiHolder.itemView.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        (new ApiController()).setActive(id);
                    }
                });
        viewApiHolder.activate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    (new ApiController()).setActive(id);
                }
            }
        });
    }

    @Override
    public long getItemId(int position) {
        return this.mValues.get(position).getId();
    }

    @Override
    public int getItemCount() {
        return this.mValues.size();
    }
    public class ViewApiHolder extends RecyclerView.ViewHolder{
        TextView name;
        SwitchCompat activate;
        TextView  type;
        TextView  letter;
        ViewApiHolder(View view) {
            super(view);
            name = (TextView) view.findViewById(R.id.name);
            type = (TextView) view.findViewById(R.id.type);
            letter = (TextView) view.findViewById(R.id.letter);
            activate = (SwitchCompat) view.findViewById(R.id.activate);
        }
    }
}
