package com.mapossa.www.sda.ThinkSpeack.controller;
import com.mapossa.www.sda.ThinkSpeack.model.*;

import java.util.ArrayList;
import java.util.List;

public class FieldController {
    static ArrayList<Field> champs;
    public FieldController() {
        if (champs==null || champs.size()==0) {
            champs = new ArrayList<Field>();
//            champs.add(new Field("Field 1", 1));
//            champs.add(new Field("Field 2", 2));
//            champs.add(new Field("Field 3", 3));
//            champs.add(new Field("Field 4", 4));
//            champs.add(new Field("Field 5", 5));
        }
    }
    public FieldController(ArrayList<Field> fd) {
        champs  = fd;
    }
    public Field activeField(){
        return getById(( new ApiController()).getActive());
    }
    public Field getById(int id){
        for (int i=0;i<champs.size();i++) {
            if(id == champs.get(i).getId())
                return champs.get(i);
        }
        return null;
    }
    public int add(Field champ){
        return 1;
    }
    public int delete(Field champ){
        return 1;
    }
    public Field get(int id){
        return null;
    }
    public ArrayList<Field> getAll(){
        return champs;
    }

    public void setActive(int active) {
        for (Field f : champs){
            if(active == f.getId()){
                f.setActivate(true);
            }else
                f.setActivate(false);
        }
        int i = 0;
        for (Field f : champs){
            if(f.isActivate()){
                i = 10000;
            }else
                i--;
        }
        if(i<0)
            champs.get(0).setActivate(true);
    }
}
