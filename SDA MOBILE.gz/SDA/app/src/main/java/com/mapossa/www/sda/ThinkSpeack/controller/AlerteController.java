package com.mapossa.www.sda.ThinkSpeack.controller;

import com.mapossa.www.sda.ThinkSpeack.model.Alerte;
import com.mapossa.www.sda.ThinkSpeack.model.Api;
import com.mapossa.www.sda.ThinkSpeack.model.Data;
import com.mapossa.www.sda.ThinkSpeack.model.Field;

import java.util.ArrayList;

public class AlerteController {

    ArrayList<Alerte> champs;

    public AlerteController() {
        champs = new ArrayList<Alerte>();
        FieldController ctrlField = new FieldController();
        ApiController ctrlApi = new ApiController();
        Field fieldActive = ctrlField.activeField();
        double min = ctrlApi.getMin();
        double max = ctrlApi.getMax();
        DataController ctrlData = new DataController();
        for(Data data : ctrlData.getAll()){
            if(min > data.getData())
                champs.add(new Alerte(1, "Less than Min value",fieldActive, data.getDate(), data.getData()));
            else if(max < data.getData())
                champs.add(new Alerte(1, "Greater than Max value",fieldActive, data.getDate(), data.getData()));
        }
    }
    public AlerteController(ArrayList<Alerte> ls) {
        champs = ls;
    }
    public Alerte getById(int id){
        for (int i=0;i<champs.size();i++) {
            if(id == champs.get(i).getId())
                return champs.get(i);
        }
        return null;
    }
    public int add(Alerte champ){
        return 1;
    }
    public int delete(Alerte champ){
        return 1;
    }
    public Alerte get(int id){
        return null;
    }
    public ArrayList<Alerte> getAll(){
        if(champs==null)
            return new ArrayList<Alerte>();
        return champs;
    }
}
