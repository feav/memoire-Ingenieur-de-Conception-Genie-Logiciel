package com.mapossa.www.sda.ThinkSpeack.view;


import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mapossa.www.sda.R;
import com.mapossa.www.sda.ThinkSpeack.controller.AlerteController;
import com.mapossa.www.sda.ThinkSpeack.controller.FieldController;
import com.mapossa.www.sda.ThinkSpeack.model.Alerte;
import com.mapossa.www.sda.ThinkSpeack.model.Field;

import java.util.List;

public class ViewAlerteAdapter
        extends RecyclerView.Adapter<ViewAlerteAdapter.ViewApiHolder> {

    private List<Alerte> mValues = (new AlerteController()).getAll();
    private final View.OnClickListener mOnClickListener =
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                  Log.v("feav","CLick on item");
                }
            };
    /**
     * ELLE RENVOIE LA VUE DEJA FORME ET REMPLACE LE TMP PAR LA VUE QUI DOIT S AFFICHER
     * @param viewGroup
     * @param i
     * @return
     */
    @NonNull
    @Override
    public ViewApiHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View  view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.alerte_view_item, viewGroup, false);
        return new ViewApiHolder(view);
    }

    /**
     * DANS CONFIGURE L AFFICHAGE
     * @param viewApiHolder LA VUE MERE DE LA VUE SUR LAQUELLE ON TRAVAIL
     * @param i L INDICE DE L ELEMENT A TRAVAILLER
     */
    @Override
    public void onBindViewHolder(@NonNull ViewApiHolder viewApiHolder, int i) {
            if(this.mValues.get(i).getField()!=null)
                viewApiHolder.name.setText(this.mValues.get(i).getField().getName());
            else
                viewApiHolder.name.setText("SOURCE ACTIVE");
            viewApiHolder.letter.setText("" + this.mValues.get(i).getValue());
            viewApiHolder.type.setText(this.mValues.get(i).getDescription());
            viewApiHolder.date.setText(this.mValues.get(i).getDate());
            viewApiHolder.itemView.setOnClickListener(mOnClickListener);
    }

    @Override
    public long getItemId(int position) {
        return this.mValues.get(position).getId();
    }

    @Override
    public int getItemCount() {
        Log.v("feav SIZE PF ELEMENTS","size = "+this.mValues.size());
        return this.mValues.size();
    }
    public class ViewApiHolder extends RecyclerView.ViewHolder{
        TextView name;
        SwitchCompat activate;
        TextView  type;
        TextView  letter;
        TextView  date;
        ViewApiHolder(View view) {
            super(view);
            name = (TextView) view.findViewById(R.id.name);
            type = (TextView) view.findViewById(R.id.type);
            activate = (SwitchCompat) view.findViewById(R.id.activate);
            letter = (TextView) view.findViewById(R.id.letter);
            date = (TextView) view.findViewById(R.id.date);
        }
    }
}
