package com.mapossa.www.sda.ThinkSpeack.view;


import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mapossa.www.sda.Activity.SourceDetailActivity;
import com.mapossa.www.sda.R;
import com.mapossa.www.sda.ThinkSpeack.controller.FieldController;
import com.mapossa.www.sda.ThinkSpeack.model.Field;

import java.util.List;

public class ViewSourceAdapter
        extends RecyclerView.Adapter<ViewSourceAdapter.ViewApiHolder> {

    private List<Field> mValues = (new FieldController()).getAll();
    private final View.OnClickListener mOnClickListener =
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Context context = view.getContext();
                    Intent intent = new Intent(context, SourceDetailActivity.class);
                    intent.putExtra("item_id", ((Field)view.getTag()).getId());

                    context.startActivity(intent);
                }
            };
    /**
     * ELLE RENVOIE LA VUE DEJA FORME ET REMPLACE LE TMP PAR LA VUE QUI DOIT S AFFICHER
     * @param viewGroup
     * @param i
     * @return
     */
    @NonNull
    @Override
    public ViewApiHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View  view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.source_view_item, viewGroup, false);
        return new ViewApiHolder(view);
    }

    /**
     * DANS CONFIGURE L AFFICHAGE
     * @param viewApiHolder LA VUE MERE DE LA VUE SUR LAQUELLE ON TRAVAIL
     * @param i L INDICE DE L ELEMENT A TRAVAILLER
     */
    @Override
    public void onBindViewHolder(@NonNull ViewApiHolder viewApiHolder, int i) {

        viewApiHolder.name.setText(this.mValues.get(i).getName());
        viewApiHolder.type.setText(this.mValues.get(i).getType());

        viewApiHolder.letter.setText("S"+this.mValues.get(i).getId());
        final int id = this.mValues.get(i).getId();
        viewApiHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = view.getContext();
                Intent intent = new Intent(context, SourceDetailActivity.class);
//                ((Field)view.getTag()).getId()
                intent.putExtra("item_id", id);
                context.startActivity(intent);
            }
        });
        if(this.mValues.get(i).isActivate())
            viewApiHolder.image.setVisibility(View.VISIBLE);
    }

    @Override
    public long getItemId(int position) {
        return this.mValues.get(position).getId();
    }

    @Override
    public int getItemCount() {
        return this.mValues.size();
    }
    public class ViewApiHolder extends RecyclerView.ViewHolder{
        TextView name;
        SwitchCompat activate;
        TextView  type;
        TextView  letter;
        ImageView image;
        ViewApiHolder(View view) {
            super(view);
            name = (TextView) view.findViewById(R.id.name);
            type = (TextView) view.findViewById(R.id.type);
            letter = (TextView) view.findViewById(R.id.letter);
            image = (ImageView)view.findViewById(R.id.activate);
            image.setVisibility(View.INVISIBLE);
        }
    }
}
