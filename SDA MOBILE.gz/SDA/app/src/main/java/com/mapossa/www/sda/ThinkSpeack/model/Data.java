package com.mapossa.www.sda.ThinkSpeack.model;

public class Data {
    private String date;
    private Double data;

    public Data(String date, Double data) {
        this.date = date;
        this.data = data;
    }

    public Data() {

    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Double getData() {
        return data;
    }

    public void setData(Double data) {
        this.data = data;
    }
}
