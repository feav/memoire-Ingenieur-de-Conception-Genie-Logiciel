package com.mapossa.www.sda.Activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.mapossa.www.sda.MainActivity;
import com.mapossa.www.sda.Network.HttpRequest;
import com.mapossa.www.sda.R;
import com.mapossa.www.sda.ThinkSpeack.controller.ApiController;
import com.mapossa.www.sda.ThinkSpeack.controller.DataController;
import com.mapossa.www.sda.ThinkSpeack.controller.FieldController;
import com.mapossa.www.sda.ThinkSpeack.model.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class InitAppActivity extends AppCompatActivity {


    private final int jsoncode = 1;
    static String url ="https://thingspeak.com/channels/514579/field/2.json";
    private int STAPE = 1;
    private int ID_FIELD = 2;
    private int ID_FEED = 514579;
    public static boolean OPEN_APP = true;
    public static Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_init_app);
        ActionBar actionBar = getSupportActionBar();
        context = getApplicationContext();

        new DataController(new ArrayList<Data>());
        new FieldController(new ArrayList<Field>());
        if((new ApiController()).getId()>0)
            ID_FEED = (new ApiController()).getId();
        if((new ApiController()).getActive()>0)
            ID_FIELD = (new ApiController()).getActive();
        else
            ID_FIELD =1;
        if (actionBar != null) {
            actionBar.hide();
        }
        if(OPEN_APP){

            try {
                parseJson();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }else {
            STAPE=2;
            try {
                parseJson();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        OPEN_APP = false;
    }
    public boolean isNetworkAvialable(){
        ConnectivityManager cM = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo nI = cM.getActiveNetworkInfo();
        if(nI != null && nI.isConnected())
            return true;
        return false;
    }
    private void startApp(){
        Intent intent = new Intent(this, MainActivity.class);
        this.startActivity(intent);
    }

    private void parseJson() throws IOException, JSONException {

        if (!isNetworkAvialable()) {
            Toast.makeText(this.getApplicationContext(), "Internet is required!", Toast.LENGTH_SHORT).show();
        }
        new AsyncTask<Void, Void, String>(){
            protected String doInBackground(Void[] params) {
                String response="";
                switch (STAPE){
                    case 1:
                        url = "https://thingspeak.com/channels/"+ID_FEED+"/feeds.json?results=0";
                        break;
                    case 2:
                        url = "https://thingspeak.com/channels/"+ID_FEED+"/field/"+ID_FIELD+".json";
                        break;
                }
                HashMap<String, String> map=new HashMap<>();
                try {
                    HttpRequest req = new HttpRequest(InitAppActivity.url);
                    response = req.prepare(HttpRequest.Method.GET).sendAndReadString();
                } catch (Exception e) {
                    response=e.getMessage();
                }
                return response;
            }
            protected void onPostExecute(String result) {
                switch (STAPE){
                    case 1:
                        onTaskCompleteInitFiels(result,jsoncode);
                        break;
                    case 2:
                        onTaskCompleted(result,jsoncode);
                        break;
                }

            }
        }.execute();
    }
    private void updateStape(){
        STAPE++;
        if(STAPE==3)
            startApp();
        else {
            try {
                parseJson();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    public void onTaskCompleteInitFiels(String response, int serviceCode){
        Log.d("responsejson------Field", response.toString());
        if (serviceCode == jsoncode) {
            ArrayList<Field> result = null;
            FieldController ctrlField;
            ApiController ctrlApi = new ApiController();
            try {
                result = ctrlApi.jsonHowManyFields(new JSONObject(response));
                ctrlField= new FieldController(result);
            } catch (JSONException e) {
                e.printStackTrace();
                updateStape();
            }
        }
        updateStape();
    }
    public void onTaskCompleted(String response, int serviceCode) {
        CharSequence text = response.toString();
        ArrayList<Data> listData = new ArrayList<Data>();
        if (serviceCode == jsoncode) {
            JSONArray dataArray = null;
            try {
                JSONObject jsonObject = new JSONObject(response);
                dataArray = jsonObject.getJSONArray("feeds");

            } catch (JSONException e) {
                e.printStackTrace();

                DataController dataCtrl =  new DataController(listData);
                updateStape();

            }
            double oldValue = 0;
            String oldString = "";
            if(dataArray!=null) {
                for (int i = 0; i < dataArray.length(); i++) {
                    JSONObject dataobj = null;
                    try {
                        dataobj = dataArray.getJSONObject(i);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Data data = new Data();
                    try {
                        data.setDate(dataobj.getString("created_at"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        double value = dataobj.getDouble("field" + ID_FIELD);
                        data.setData(value);
                        oldValue = value;
                    }catch (JSONException e) {
                        data.setData(oldValue);
                    }finally {
                    }
                    listData.add(data);
                }
            }
        }else{
            Toast.makeText(this.getApplicationContext(), "Check your internet connexion", Toast.LENGTH_LONG).show();
        }
        DataController dataCtrl =  new DataController(listData);
        updateStape();

    }
}
