package com.mapossa.www.sda.ThinkSpeack.model;

import java.util.ArrayList;

public class Field {
    private String name;
    private int id;
    private String postUrl;
    private String getUrl;
    private String type;
    private boolean activate;
    private ArrayList<Data> datas;
    public Field(String name, int id) {
        this.name = name;
        this.id = id;
        this.activate = id == 1;
        this.type = "Humidite";
        datas = new ArrayList<>();
    }
    public Field(String name, int id,String type) {
        this.name = name;
        this.id = id;
        this.type = type;
        this.activate = false;
        datas = new ArrayList<>();
    }

    public ArrayList<Data> getDatas() {
        return datas;
    }

    public void setDatas(ArrayList<Data> datas) {
        this.datas = datas;
    }

    public boolean isActivate() {
        return activate;
    }

    public void setActivate(boolean activate) {
        this.activate = activate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPostUrl() {
        return postUrl;
    }

    public void setPostUrl(String postUrl) {
        this.postUrl = postUrl;
    }

    public String getGetUrl() {
        return getUrl;
    }

    public void setGetUrl(String getUrl) {
        this.getUrl = getUrl;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
