package com.mapossa.www.sda.ThinkSpeack.controller;

import android.graphics.Color;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.mapossa.www.sda.R;
import com.mapossa.www.sda.ThinkSpeack.model.Data;

import java.util.ArrayList;
import java.util.List;

public class LineChartController {

    private LineChart chart;
    private ArrayList<Data> datas;
    private String name;
    private int min = 20;
    private int max = 10;
    public LineChartController(LineChart root, ArrayList<Data> donnees,String nom){
        chart = root;
        datas = donnees;
        if (donnees==null)
            datas  = new ArrayList<Data>();
        name = nom;
    }

    public LineChart getChart() {
        return chart;
    }

    public void setChart(LineChart chart) {
        this.chart = chart;
    }

    public ArrayList<Data> getDatas() {
        return datas;
    }

    public void setDatas(ArrayList<Data> datas) {
        this.datas = datas;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public void refresh(){
        if (datas.size()==0)
            return;
        List<Entry> entries = new ArrayList<Entry>();
        List<Entry> minEntries = new ArrayList<Entry>();
        List<Entry> maxEntries = new ArrayList<Entry>();
        min = (int)(new ApiController()).getMin();
        max = (int)(new ApiController()).getMax();
        for (int i = 0; i < datas.size(); i++){
            entries.add(new Entry(i,(int) (double) datas.get(i).getData()));
            minEntries.add(new Entry(i,min));
            maxEntries.add(new Entry(i,max));
        }
        LineDataSet dataSet = new LineDataSet(entries, name);
        dataSet.setColor(Color.parseColor("#449881"));
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setCircleColor(Color.parseColor("#24554a"));

        LineDataSet dataSetMin = new LineDataSet(minEntries, "Min limit");
        dataSetMin.setColor(Color.RED);
        dataSetMin.setValueTextColor(Color.argb(0,0,0,0));
        dataSetMin.setCircleColor(Color.argb(0,0,0,0));

        LineDataSet dataSetMax = new LineDataSet(maxEntries, "Max limit");
        dataSetMax.setColor(Color.RED);
        dataSetMax.setValueTextColor(Color.argb(0,0,0,0));
        dataSetMax.setCircleColor(Color.argb(0,0,0,0));

        LineData lineData = new LineData(dataSet,dataSetMin,dataSetMax);
        chart.setData(lineData);
        chart.invalidate();
    }
}
