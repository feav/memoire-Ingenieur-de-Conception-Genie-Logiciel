package com.mapossa.www.sda.ThinkSpeack.controller;

import android.graphics.Color;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.mapossa.www.sda.ThinkSpeack.model.Data;

import java.util.ArrayList;
import java.util.List;

public class BarChartController {

    private BarChart chart;
    private ArrayList<Data> datas;
    private String name;
    public BarChartController(BarChart root, ArrayList<Data> donnees, String nom){
        chart = root;
        datas = donnees;
        name = nom;
    }

    public BarChart getChart() {
        return chart;
    }

    public void setChart(BarChart chart) {
        this.chart = chart;
    }

    public ArrayList<Data> getDatas() {
        return datas;
    }

    public void setDatas(ArrayList<Data> datas) {
        this.datas = datas;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void refresh(){
        List<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(0f, 30f));
        entries.add(new BarEntry(1f, 80f));
        for (int i = 0; i < datas.size(); i++)
            entries.add(new BarEntry(i+1f,(float) (double) datas.get(i).getData()));
        BarDataSet set = new BarDataSet(entries, name);

        set.setColor(Color.parseColor("#449881"));
        set.setValueTextColor(Color.BLACK);
        BarData data = new BarData(set);
        data.setBarWidth(0.9f); // set custom bar width
        chart.setData(data);
        chart.setFitBars(true); // make the x-axis fit exactly all bars
        chart.invalidate(); // refresh
    }
}
