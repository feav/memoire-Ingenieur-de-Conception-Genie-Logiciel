package com.mapossa.www.sda.Activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.mapossa.www.sda.MainActivity;
import com.mapossa.www.sda.Network.HttpRequest;
import com.mapossa.www.sda.R;
import com.mapossa.www.sda.ThinkSpeack.controller.ApiController;
import com.mapossa.www.sda.ThinkSpeack.controller.BarChartController;
import com.mapossa.www.sda.ThinkSpeack.controller.DataController;
import com.mapossa.www.sda.ThinkSpeack.controller.FieldController;
import com.mapossa.www.sda.ThinkSpeack.controller.LineChartController;
import com.mapossa.www.sda.ThinkSpeack.model.Data;
import com.mapossa.www.sda.ThinkSpeack.model.Field;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class SourceDetailActivity extends AppCompatActivity {
    private final int jsoncode = 1;
    private int ID_FIELD = 2;
    private int ID_FEED = 514579;
    Context context;
    Dialog dialog;
    Dialog waitingDialog;
    String url;
    String API_KEY;

    public SourceDetailActivity() {
        dialog = null;
    }

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_source_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        context = getApplicationContext();

        dialog= new Dialog(this);
        waitingDialog = new Dialog(this);
        waitingDialog.setContentView(R.layout.loading);
        waitingDialog.setCanceledOnTouchOutside(true);
        waitingDialog.setTitle("Chargement...");
        waitingDialog.show();
        if((new ApiController()).getId()>0)
            ID_FEED = (new ApiController()).getId();
//        if((new ApiController()).getActive()>0)
//            ID_FIELD = (new ApiController()).getActive();
//        else
//            ID_FIELD =1;
        API_KEY = (new ApiController()).getKey();
        ID_FIELD = getIntent().getIntExtra("item_id",1);

        try {
            parseJson();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog = new Dialog(view.getContext());
                dialog.setContentView(R.layout.send_data_view);
                dialog.setCanceledOnTouchOutside(true);
                dialog.setTitle("Pushing data");
                dialog.show();
                final EditText edit = (EditText)dialog.findViewById(R.id.value);
                ImageButton send = (ImageButton)dialog.findViewById(R.id.valueButton);
                send.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        try {
                            sendJson(edit.getText().toString());
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        dialog.dismiss();
                        waitingDialog.show();
                    }
                });
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setShowHideAnimationEnabled(true);
    }

    public boolean isNetworkAvialable(){
        ConnectivityManager cM = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo nI = cM.getActiveNetworkInfo();
        if(nI != null && nI.isConnected())
            return true;
        return false;
    }

    private void sendJson(String v) throws IOException, JSONException {

        if (!isNetworkAvialable()) {
            Toast.makeText(context, "Internet is required!", Toast.LENGTH_SHORT).show();
        }
        final String VAL = v;
        new AsyncTask<Void, Void, String>(){
            protected String doInBackground(Void[] params) {
                String response="";

                String urle = "https://api.thingspeak.com/update?api_key="+API_KEY+"&field"+ID_FIELD+"="+VAL;

                HashMap<String, String> map=new HashMap<>();
                try {
                    HttpRequest req = new HttpRequest(urle);
                    Log.d("feavAddURL",urle);
                    response = req.prepare(HttpRequest.Method.GET).sendAndReadString();
                } catch (Exception e) {
                    response=e.getMessage();
                }
                return response;
            }
            protected void onPostExecute(String result) {
                Log.d("feavAdd",result);
                Toast.makeText(context,"You just send your "+result+ " datas",Toast.LENGTH_SHORT).show();

                waitingDialog.show();
                try {
                    parseJson();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }.execute();
    }
    private void parseJson() throws IOException, JSONException {

        if (!isNetworkAvialable()) {
            Toast.makeText(context, "Internet is required!", Toast.LENGTH_SHORT).show();
        }

        new AsyncTask<Void, Void, String>(){
            protected String doInBackground(Void[] params) {
                String response="";

                url = "https://thingspeak.com/channels/"+ID_FEED+"/field/"+ID_FIELD+".json";

                HashMap<String, String> map=new HashMap<>();
                try {
                    HttpRequest req = new HttpRequest(url);
                    response = req.prepare(HttpRequest.Method.GET).sendAndReadString();
                } catch (Exception e) {
                    response=e.getMessage();
                }
                return response;
            }
            protected void onPostExecute(String result) {
                        onTaskCompleted(result,jsoncode);

            }
        }.execute();
    }
    private void updateStape(){
    }
    public void onTaskCompleted(String response, int serviceCode) {
        CharSequence text = response.toString();
        if (serviceCode == jsoncode) {
            ArrayList<Data> listData = new ArrayList<Data>();
            JSONArray dataArray = null;
            try {
                JSONObject jsonObject = new JSONObject(response);
                dataArray = jsonObject.getJSONArray("feeds");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            double oldValue = 0;
            String oldString = "";
            if(dataArray!=null) {
                for (int i = 0; i < dataArray.length(); i++) {
                    JSONObject dataobj = null;
                    try {
                        dataobj = dataArray.getJSONObject(i);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Data data = new Data();
                    try {
                        data.setDate(dataobj.getString("created_at"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        double value = dataobj.getDouble("field" + ID_FIELD);
                        data.setData(value);
                        oldValue = value;
                    }catch (JSONException e) {
                        data.setData(oldValue);
                    }finally {
                    }
                    listData.add(data);
                }
            }

            DataController datasCtrl = new DataController();
            BarChartController chart = new BarChartController(
                    (BarChart) findViewById(R.id.chart),
                    listData,
                    "Datas Souce "+ID_FIELD);
            Field f = (new FieldController()).activeField();
            chart.refresh(); // refresh
        }else{
        }
        waitingDialog.dismiss();

    }

}
