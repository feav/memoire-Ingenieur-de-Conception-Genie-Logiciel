package com.mapossa.www.sda.ThinkSpeack.model;
import  com.mapossa.www.sda.ThinkSpeack.model.Field;

public class Alerte {
    private int id;
    private String description;
    private Field field;
    private String date;
    private Double value;

    public Alerte(int id, String description, Field field, String date, Double value) {
        this.id = id;
        this.description = description;
        this.field = field;
        this.date = date;
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Field getField() {
        return field;
    }

    public void setField(Field field) {
        this.field = field;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
