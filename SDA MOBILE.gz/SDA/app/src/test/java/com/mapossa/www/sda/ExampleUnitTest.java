package com.mapossa.www.sda;

import org.junit.Test;

import java.util.zip.DeflaterOutputStream;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void convert_double_int_isCorrect() {
        Double D = 10.10;
        double d = (double)  D;
        int i = (int) d;
         assertEquals(10, i);
    }
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}