package com.mapossa.www.sda;

import com.mapossa.www.sda.ThinkSpeack.controller.FieldController;
import com.mapossa.www.sda.ThinkSpeack.model.Field;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

public class FieldControllerTest {

    FieldController ctrlField;
    @Test
    public void findById_isCorrect() {
        ArrayList<Field> champs = new ArrayList<Field>();
        champs.add(new Field("Field 1",1));
        champs.add(new Field("Field 2",2));
        champs.add(new Field("Field 3",3));
        champs.add(new Field("Field 4",5));
        champs.add(new Field("Field 5",6));
        ctrlField = new FieldController(champs);
        assertEquals(1, ctrlField.getById(1).getId());
        assertEquals(2, ctrlField.getById(2).getId());
        assertEquals(3, ctrlField.getById(3).getId());
    }
}
